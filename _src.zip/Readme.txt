1. Chapter 2 shows how to connect and query Hive using JDBC. 
	a. import the project as maven project
	b. compile project with maven command "mvn clean install -DskipTests"
	c. execute the project as java application

2. Chapter 9 shows how to create a UDF in Hive
	a. import the project in eclipse as java project
	b. add jars available in lib folder to classpath of project
	c. export the project as normal jar, register the jar in Hive and use the function.